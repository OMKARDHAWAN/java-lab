package com.demo.model;

public class Exception  extends RuntimeException  {
	 public Exception(String message) 
	    {
	        super(message);
	    }
}
