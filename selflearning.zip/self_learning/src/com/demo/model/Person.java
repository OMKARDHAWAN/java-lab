package com.demo.model;

public class Person {
 private String name;
 private int age;
 
 Person(){
	 name = "";
	 age = 0;
 }

 public Person( String name, int age) {
	super();
	this.name = name;
	this.age = age;
 }

 public String getName() {
	return name;
}

 public void setName(String name) {
	this.name = name;
 }

 public int getAge() {
	return age;
 }

 public void setAge(int age) {
	this.age = age;
 }
 
 
 


 

 
 
 
 
 
 
}
