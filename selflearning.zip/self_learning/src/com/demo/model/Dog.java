package com.demo.model;


public class Dog extends Animal {
    @Override
    public void sound() {
        System.out.println("Dog barks");
    }
}
