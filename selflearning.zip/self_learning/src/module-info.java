/**
 * 
 */
/**
 * 
 */
module self_learning {
}